import { useParams, useNavigate } from "react-router-dom";
import { useEffect, useState } from "react";
import API from "../../../services/api";
import "../../../styles/My-project-details.css";

const ProjectDetails = () => {
  const { id } = useParams();
  const navigate = useNavigate();

  const [project, setProject] = useState<any>(null);
  const [tab, setTab] = useState("requests");
  const [requests, setRequests] = useState<any[]>([]);
  const [members, setMembers] = useState<any[]>([]);
  const [loading, setLoading] = useState(false);

  // ================= FETCH PROJECT =================
  const fetchProject = async () => {
    const res = await API.get(`/projects/${id}`);
    setProject(res.data);
  };

  // ================= FETCH REQUESTS =================
  const fetchRequests = async () => {
    const res = await API.get(`/projects/${id}/requests`);
    setRequests(res.data.data);
  };

  // ================= FETCH MEMBERS =================
  const fetchMembers = async () => {
    const res = await API.get(`/projects/${id}/members`);
    setMembers(res.data.data);
  };

  useEffect(() => {
    fetchProject();
    fetchRequests();
    fetchMembers();
  }, [id]);

  // ================= ACTIONS =================
  const accept = async (userId: string) => {
    await API.post(`/projects/${id}/accept/${userId}`);
    fetchRequests();
    fetchMembers();
  };

  const reject = async (userId: string) => {
    await API.post(`/projects/${id}/reject/${userId}`);
    fetchRequests();
  };

  const removeMember = async (userId: string) => {
    await API.post(`/projects/${id}/remove/${userId}`);
    fetchMembers();
  };

  if (!project) return <p>Loading...</p>;

  return (
    <div className="pd-container">

      <button onClick={() => navigate(-1)}>← Back</button>

      {/* ================= TOP GLASS CARD ================= */}
      <div className="pd-glass">

        <div className="pd-top">
          <h2>{project.title}</h2>
          <span className="pd-status">
            {project.status === "active" ? "Open" : "Closed"}
          </span>
        </div>

        <p className="pd-desc">{project.description}</p>

        <p>
          Members: {project.members_count}/{project.required_members}
        </p>

        {/* OWNER ACTIONS */}
        {project.is_owner && (
          <div className="pd-actions">
            <button>Edit</button>
            <button className="danger">Delete</button>
            <button className="success">Complete</button>
          </div>
        )}
      </div>

      {/* ================= TABS ================= */}
      <div className="pd-tabs">
        <button onClick={() => setTab("requests")}>Requests</button>
        <button onClick={() => setTab("members")}>Members</button>
        <button onClick={() => setTab("tasks")}>Tasks</button>
        <button onClick={() => setTab("mentor")}>Mentor</button>
      </div>

      {/* ================= TAB CONTENT ================= */}
      <div className="pd-content">

        {/* REQUESTS */}
        {tab === "requests" && (
          <div>
            {requests.map((r) => (
              <div key={r.user_id} className="pd-card">
                <p>{r.name}</p>
                <p>{r.department}</p>
                <p>{r.reg_no}</p>

                {project.is_owner && (
                  <>
                    <button onClick={() => accept(r.user_id)}>Accept</button>
                    <button onClick={() => reject(r.user_id)}>Reject</button>
                  </>
                )}
              </div>
            ))}
          </div>
        )}

        {/* MEMBERS */}
        {tab === "members" && (
          <div>
            {members.map((m) => (
              <div key={m.user_id} className="pd-card">
                <p>{m.name}</p>
                <p>{m.department}</p>

                {project.is_owner && (
                  <button onClick={() => removeMember(m.user_id)}>
                    Remove
                  </button>
                )}
              </div>
            ))}
          </div>
        )}

        {/* TASKS */}
        {tab === "tasks" && <p>Tasks module coming...</p>}

        {/* MENTOR */}
        {tab === "mentor" && <p>Mentor search coming...</p>}

      </div>

    </div>
  );
};

export default ProjectDetails;