import { useParams, useNavigate } from "react-router-dom";
import "../../../styles/Member-Projects-Details.css";

const ProjectDetails = () => {
  const { id } = useParams();
  const navigate = useNavigate();

  return (
    <div className="pd-container">

      <button onClick={() => navigate(-1)}>← Back</button>

      {/* TOP CARD */}
      <div className="pd-top">
        <h2>Project {id}</h2>
        <span className="pd-status">Open</span>
      </div>

      {/* DESCRIPTION */}
      <p className="pd-desc">
        This is project description...
      </p>

      {/* MEMBERS */}
      <p>Members: 2/14</p>

      {/* STATUS TOGGLE */}
      <div className="pd-toggle">
        <button className="active">Open</button>
        <button>Close</button>
      </div>

      {/* ACTIONS */}
      <div className="pd-actions">
        <button>Edit Project</button>
        <button className="danger">Delete</button>
        <button className="success">Request to Complete</button>
      </div>

      {/* TABS */}
      <div className="pd-tabs">
        <button>Requests</button>
        <button>Tasks</button>
        <button>Mentor Search</button>
      </div>

      {/* CONTENT AREA */}
      <div className="pd-content">
        <p>Tab content here...</p>
      </div>

    </div>
  );
};

export default ProjectDetails;