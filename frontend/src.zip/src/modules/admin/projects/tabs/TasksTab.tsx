const TasksTab = ({ projectId }: any) => {

  return (
    <div>
      <p>Tasks will appear here</p>
    </div>
  );

};

export default TasksTab;