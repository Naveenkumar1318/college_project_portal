import { useEffect, useState } from "react";
import {
  getOwnProjects,
  getWorkProjects,
  getProjectDetail,
  updateProjectStatus,
  removeMember,
  deleteProject,
  completeProject
} from "../../services/projectApi";

import API from "../../services/api";
import "../../styles/student/MyProjects.css";
import toast from "react-hot-toast";

function MyProjects() {

  const [activeSection, setActiveSection] = useState(null);
  const [projects, setProjects] = useState([]);
  const [selectedProject, setSelectedProject] = useState(null);
  const [activeTab, setActiveTab] = useState("members");

  /* ================= LOAD PROJECTS ================= */

  useEffect(() => {
    loadProjects();
  }, [activeSection]);

  const loadProjects = async () => {

    if (!activeSection) return;

    try {

      let data;

      if (activeSection.includes("own")) {
        data = await getOwnProjects();
      } else {
        data = await getWorkProjects();
      }

      const filtered = data.filter(p =>
        activeSection.includes("current")
          ? p.status !== "COMPLETED"
          : p.status === "COMPLETED"
      );

      setProjects(filtered);

    } catch {
      toast.error("Failed to load projects");
    }

  };

  /* ================= OPEN PROJECT ================= */

  const openProject = async (id) => {

    try {

      const data = await getProjectDetail(id);

      setSelectedProject(data);
      setActiveTab("members");

    } catch {

      toast.error("Failed to load project");

    }

  };

  /* ================= REQUEST ACTIONS ================= */

  const handleAccept = async (studentId) => {

    try {

      await API.post(`/projects/${selectedProject.id}/accept/${studentId}`);

      toast.success("Request accepted");

      openProject(selectedProject.id);

    } catch {

      toast.error("Failed to accept request");

    }

  };

  const handleReject = async (studentId) => {

    try {

      await API.delete(`/projects/${selectedProject.id}/remove/${studentId}`);

      toast.success("Request rejected");

      openProject(selectedProject.id);

    } catch {

      toast.error("Failed to reject request");

    }

  };

  /* ================= PROJECT ACTIONS ================= */

  const changeStatus = async (status) => {
    await updateProjectStatus(selectedProject.id, status);
    openProject(selectedProject.id);
  };

  const handleRemove = async (id) => {
    await removeMember(selectedProject.id, id);
    openProject(selectedProject.id);
  };

  const handleDelete = async () => {
    await deleteProject(selectedProject.id);
    setSelectedProject(null);
    loadProjects();
  };

  const handleComplete = async () => {
    await completeProject(selectedProject.id);
    openProject(selectedProject.id);
  };

  /* ================= PROJECT DETAIL VIEW ================= */

  if (selectedProject) {

    const isCompleted = selectedProject.status === "COMPLETED";

    return (

      <div className="detail-container">

        <button
          className="back-btn"
          onClick={() => setSelectedProject(null)}
        >
          ← Back
        </button>

        {/* PROJECT CARD */}

        <div className="detail-card">

          <div className="detail-header">

            <div>
              <h2>{selectedProject.title}</h2>
              <p>{selectedProject.description}</p>
            </div>

            <div className={`status-badge ${selectedProject.status.toLowerCase()}`}>
              {selectedProject.status}
            </div>

          </div>

          <div className="meta-row">

            <span>
              👥 {selectedProject.members?.length || 0} Members
            </span>

            <span>
              🎓 Mentor: {selectedProject.mentor_name || "Not Assigned"}
            </span>

          </div>

          {!isCompleted && (
            <>
              <div className="status-switch">

                <button
                  className={selectedProject.status === "OPEN" ? "active" : ""}
                  onClick={() => changeStatus("OPEN")}
                >
                  Open
                </button>

                <button
                  className={selectedProject.status === "IN_PROGRESS" ? "active" : ""}
                  onClick={() => changeStatus("IN_PROGRESS")}
                >
                  In Progress
                </button>

              </div>

              <div className="action-row">

                <button className="view-btn">
                  View
                </button>

                <button className="edit-btn">
                  Edit
                </button>

                <button
                  className="danger-btn"
                  onClick={handleDelete}
                >
                  Delete
                </button>

                <button
                  className="complete-btn"
                  onClick={handleComplete}
                >
                  Complete
                </button>

              </div>
            </>
          )}

          {isCompleted && (
            <button className="certificate-btn">
              Download Certificate
            </button>
          )}

        </div>

        {/* ================= TABS ================= */}

        {!isCompleted && (

          <>
            <div className="tab-row">

              <button
                className={activeTab === "members" ? "active-tab" : ""}
                onClick={() => setActiveTab("members")}
              >
                Team Members
              </button>

              <button
                className={activeTab === "requests" ? "active-tab" : ""}
                onClick={() => setActiveTab("requests")}
              >
                Requests ({selectedProject.requests?.length || 0})
              </button>

              <button
                className={activeTab === "mentor" ? "active-tab" : ""}
                onClick={() => setActiveTab("mentor")}
              >
                Search Mentor
              </button>

            </div>

            {/* MEMBERS TAB */}

            {activeTab === "members" && (

              <div className="member-grid">

                {selectedProject.members?.map(member => (

                  <div key={member.id} className="member-card">

                    <img
                      src={`http://localhost:8000${member.photo}`}
                      alt=""
                    />

                    <h4>{member.name}</h4>

                    <p>{member.register_number}</p>

                    <div className="member-actions">

                      {!member.is_owner && (

                        <button
                          className="danger-btn"
                          onClick={() => handleRemove(member.id)}
                        >
                          Remove
                        </button>

                      )}

                    </div>

                  </div>

                ))}

              </div>

            )}

            {/* REQUEST TAB */}

            {activeTab === "requests" && (

              <div className="member-grid">

                {selectedProject.requests?.length === 0 ? (

                  <div className="empty-state">
                    No pending requests
                  </div>

                ) : (

                  selectedProject.requests.map(req => (

                    <div key={req.id} className="member-card">

                      <img
                        src={`http://localhost:8000${req.photo}`}
                        alt=""
                      />

                      <h4>{req.name}</h4>

                      <p>{req.register_number}</p>

                      <p>{req.department}</p>

                      <div className="member-actions">

                        <button
                          className="complete-btn"
                          onClick={() => handleAccept(req.id)}
                        >
                          Accept
                        </button>

                        <button
                          className="danger-btn"
                          onClick={() => handleReject(req.id)}
                        >
                          Reject
                        </button>

                      </div>

                    </div>

                  ))

                )}

              </div>

            )}

            {/* SEARCH MENTOR TAB */}

            {activeTab === "mentor" && (

              <div className="mentor-search">

                <input
                  type="text"
                  placeholder="Search mentor..."
                  className="mentor-input"
                />

                <button className="view-btn">
                  Search
                </button>

              </div>

            )}

          </>
        )}

      </div>

    );

  }

  /* ================= MAIN PAGE ================= */

  const sections = [
    { key: "own-current", label: "Own Current" },
    { key: "own-completed", label: "Own Completed" },
    { key: "work-current", label: "Work Current" },
    { key: "work-completed", label: "Work Completed" }
  ];

  return (

    <div className="main-container">

      <h2 className="page-title">
        My Projects
      </h2>

      <div className="top-card-grid">

        {sections.map(sec => (

          <div
            key={sec.key}
            className={`top-card ${activeSection === sec.key ? "active" : ""}`}
            onClick={() =>
              setActiveSection(prev =>
                prev === sec.key ? null : sec.key
              )
            }
          >

            <div className="card-title">
              {sec.label}
            </div>

            <div className="card-count">
              {activeSection === sec.key ? projects.length : 0}
            </div>

          </div>

        ))}

      </div>

      {activeSection && (

        <>
          <h3 className="section-heading">
            {sections.find(s => s.key === activeSection)?.label}
          </h3>

          <div className="project-grid">

            {projects.length === 0 ? (

              <div className="empty-state">
                No projects available
              </div>

            ) : (

              projects.map(project => (

                <div
                  key={project.id}
                  className="project-card"
                  onClick={() => openProject(project.id)}
                >

                  <h3>{project.title}</h3>

                  <p>{project.description}</p>

                  <div className="card-meta">

                    <span>
                      👥 {project.team_count} Members
                    </span>

                    <span>
                      🎓 {project.mentor_name || "No Mentor"}
                    </span>

                  </div>

                </div>

              ))

            )}

          </div>

        </>

      )}

    </div>

  );

}

export default MyProjects;